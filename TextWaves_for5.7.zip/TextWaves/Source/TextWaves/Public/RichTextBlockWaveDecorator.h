// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/RichTextBlockDecorator.h"
#include "Framework/Text/SlateTextRun.h"
#include "RichTextBlockWaveDecorator.generated.h"

UENUM()
enum class UpdateMode : uint8
{
	/** real application time.*/
	AutoRealGameTime,
	/** world/game time. Affected by pause and time dilation. */
	//todo: 无效, 下个版本开发
	/*AutoWorldTime,*/
	/** manually assigned time values. */
	Manual,
};

USTRUCT(BlueprintType)
struct FWaveCharAttriContext
{
	GENERATED_BODY()

	FWaveCharAttriContext():
	Position(FVector2D::ZeroVector),
	Center(FVector2D::ZeroVector),
	Scale(1.f),
	Angle(0.f),
	Color(FColor::White)
	{}
	FWaveCharAttriContext(FVector2D InPosition, FVector2D InCenter, FLinearColor InColor):
	Position(InPosition),
	Center(InCenter),
	Scale(1.f),
	Angle(0.f),
	Color(InColor)
	{}
	
	/** Glyph render position. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Wave Char Attribute")
	FVector2D Position;
	/** Glyph rotation/Scaled pivot position. (0.5 init)*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Wave Char Attribute")
	FVector2D Center;
	/** Glyph render scale. (1 init) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Wave Char Attribute")
	float Scale;
	/** Glyph rotation angle in degrees. (0 init)*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Wave Char Attribute")
	float Angle;
	/** Glyph render color. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Wave Char Attribute")
	FLinearColor Color;
};

DECLARE_DELEGATE_ThreeParams(FWaveCharDelegate, const int32, const float, FWaveCharAttriContext&);

class FRichTextWaveRun : public FSlateTextRun
{
public:
	FRichTextWaveRun();
	FRichTextWaveRun( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FTextRange& InRange );
	
	virtual int32 OnPaint(const FPaintArgs& PaintArgs, const FTextArgs& TextArgs, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	FWaveCharDelegate CharDelegate;
	
	void UpdateManualTime(float InTime, bool SwitchToManualMode = true);
	void SetUpdateMode(UpdateMode InMode, bool KeepCurrent = true);
	float GetUpdateTime() const;
	float GetTimeByMode(UpdateMode InMode, bool RawTime) const;
	
private:
	UpdateMode Mode = UpdateMode::AutoRealGameTime;
	float ManualTime = 0.f;
	//手动时间和自动时间之间的差距,在变换模式时需要储存或读取
	float GapTime = 0.f;
};


class FRichTextWaveDecorator : public ITextDecorator
{
	public:
	FRichTextWaveDecorator(URichTextBlock* InOwner);
	virtual ~FRichTextWaveDecorator() {}
	
	virtual bool Supports(const FTextRunParseResults& RunParseResult, const FString& Text) const override;

	virtual TSharedRef<ISlateRun> Create(const TSharedRef<class FTextLayout>& TextLayout, const FTextRunParseResults& RunParseResult, const FString& OriginalText, const TSharedRef< FString >& InOutModelText, const ISlateStyle* Style) override;

	URichTextBlock* Owner;

	TObjectPtr<class URichTextBlockWaveDecorator> UWaveBlock;
};

DECLARE_DELEGATE_TwoParams(FOnUpdateTime, const float, const bool);
DECLARE_DELEGATE_TwoParams(FOnSetUpdateMode, const UpdateMode, const bool);
DECLARE_DELEGATE_RetVal(float, FOnGetTime);

UCLASS(Blueprintable)
class TEXTWAVES_API URichTextBlockWaveDecorator : public URichTextBlockDecorator
{
	GENERATED_BODY()

public:
	virtual TSharedPtr<ITextDecorator> CreateDecorator(URichTextBlock* InOwner) override;
	
	FOnUpdateTime OnUpdateTime;
	FOnSetUpdateMode OnSetUpdateMode;
	FOnGetTime OnGetTime;
	
	/**
	* Rich text tag keyword handled by this decorator.
	*
	* Example: <wave>Hello World</>
	*
	* Only text wrapped with this tag will use the custom animated rendering logic.
	* Multiple decorators can coexist by using different keywords.
	*/
	UPROPERTY(EditAnywhere, Category="Rich Text Block Wave Decorator")
	FString KeyWord = TEXT("wave");

	/**
	* Initial animation time update mode used when the decorator is created.
	*/
	UPROPERTY(EditAnywhere, Category="Rich Text Block Wave Decorator")
	UpdateMode StartMode = UpdateMode::AutoRealGameTime;

	/**
	* Manually sets the current animation time.
	*
	* Can optionally switch the decorator into manual update mode immediately.
	* Useful for timeline-driven animations, sequencer control, syncing text
	* effects with gameplay events, or deterministic playback.
	*
	* @param InTime New animation time in seconds.
	* @param SwitchToManualMode If true, automatically switches the update mode to Manual.
	*/
	UFUNCTION(BlueprintCallable, Category="Rich Text Block Wave Decorator")
	void UpdateManualTime(float InTime, bool SwitchToManualMode = true);
	
	/**
	* Changes how animation time is updated.
	*
	* Allows switching between automatic engine-driven time and externally controlled manual time.
	*
	* @param InMode New update mode.
	* @param KeepCurrent If true, preserves the current evaluated time when switching modes to avoid visible animation discontinuities.
	*/
	//todo: 下个版本开发
	/*UFUNCTION(BlueprintCallable, Category="Rich Text Block Wave Decorator")
	void SetUpdateMode(UpdateMode InMode, bool KeepCurrent = true);*/
	
	/**
	* Returns the current evaluated animation time in seconds.
	*
	* Useful for synchronization, debugging, and custom animation logic.
	*
	* @return Current animation time in seconds.
	*/
	//todo: 下个版本开发
	/*UFUNCTION(BlueprintCallable, BlueprintPure, Category="Rich Text Block Wave Decorator")
	float GetCurrentTime();*/
	
	/**
	* Per-glyph custom animation callback.
	*
	* Note:This function is executed extremely frequently (potentially every frame
	* for every visible glyph), so implementations should remain lightweight.
	* 
	* @param CharIndex Visual index of the current rendered glyph.
	* @param CurrentTime Current running time in seconds.
	* @param CharAttriContext Mutable rendering context for the current glyph. Modify its fields to change position, scale, etc.(set by ref) .
	*/
	UFUNCTION(BlueprintNativeEvent)
	void CustomPerChar(const int32 CharIndex, const float CurrentTime, UPARAM(ref) FWaveCharAttriContext& CharAttriContext);
};

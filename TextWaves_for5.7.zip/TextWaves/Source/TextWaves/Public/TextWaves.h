// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Kismet/KismetStringLibrary.h"
#include "Modules/ModuleManager.h"


class FTextWavesModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};

#if 0
namespace DebugHelper
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *message);
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
	static void Print(int message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *FString::FromInt(message));
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}

	static void Print(double message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *FString::FromInt(message));
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, UKismetStringLibrary::Conv_DoubleToString(message));
		}
	}
}
#endif
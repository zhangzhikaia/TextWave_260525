// Copyright lurongjiu 2026 All Rights Reserved.

#include "RichTextBlockWaveDecorator.h"
#include "TextWaves.h"
#include "Fonts/FontMeasure.h"
#include "GameTime.h"
#include "Components/RichTextBlock.h"
#include "Framework/Text/ShapedTextCache.h"

FRichTextWaveRun::FRichTextWaveRun(const FRunInfo& InRunInfo, const TSharedRef<const FString>& InText,const FTextBlockStyle& InStyle, const FTextRange& InRange)
: FSlateTextRun(InRunInfo,InText,InStyle,InRange)
{
}

int32 FRichTextWaveRun::OnPaint(const FPaintArgs& PaintArgs, const FTextArgs& TextArgs,const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements,int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	const ESlateDrawEffect DrawEffects = bParentEnabled ? ESlateDrawEffect::None: ESlateDrawEffect::DisabledEffect;
	const TSharedRef<ILayoutBlock>& Block = TextArgs.Block;
	//const FTextBlockStyle& DefaultStyle = TextArgs.DefaultStyle;
	const FTextLayout::FLineView& Line = TextArgs.Line;
	
	const FTextRange BlockRange = Block->GetTextRange();
	const FLayoutBlockTextContext BlockTextContext = Block->GetTextContext();
	
	const float InverseScale = Inverse(AllottedGeometry.Scale);

	//初始整体位置偏移量
	const FVector2D BlockLocationOffset = Block->GetLocationOffset();
	const FVector2D PaintBlockOffset = TransformPoint(InverseScale,	BlockLocationOffset);

	//初始scale(随视口缩放, 产生的尺寸缩放. 不适合输出)
	const float StartScale = AllottedGeometry.GetAccumulatedLayoutTransform().GetScale();

	//范围内的完整文本, 只应用默认初始值, 以计算原始属性, 例如字间距等
	FShapedGlyphSequenceRef ShapedText = ShapedTextCacheUtil::GetShapedTextSubSequence(
		BlockTextContext.ShapedTextCache,
		FCachedShapedTextKey(Line.Range, StartScale, BlockTextContext, Style.Font),
		BlockRange,
		**Text,
		BlockTextContext.TextDirection
	);

	//文本中全部应渲染的Glyph(Glyph:理解为一个单位, 非一个字符, 例如emoji并非一个字符组成, 但输出为一个Glyph
	TArray<FShapedGlyphEntry> GlyphEntrys = ShapedText->GetGlyphsToRender();

	//预配置阴影所需属性, 非逐Glyph的. 渲染shadow本质就是渲染多一个字符
	const bool ShouldDropShadow = Style.ShadowColorAndOpacity.A > 0.f && Style.ShadowOffset.SizeSquared() > 0.f;
	FSlateFontInfo ShadowFontInfo = Style.Font;
	ShadowFontInfo.OutlineSettings.OutlineColor = Style.ShadowColorAndOpacity;
	ShadowFontInfo.OutlineSettings.OutlineMaterial = nullptr;
	if (!ShadowFontInfo.OutlineSettings.bApplyOutlineToDropShadows)
	{
		ShadowFontInfo.OutlineSettings.OutlineSize = 0;
	}
	FVector2D DrawShadowOffset(
		(Style.ShadowOffset.X > 0.0f) ? Style.ShadowOffset.X * AllottedGeometry.Scale : 0.0f,
		(Style.ShadowOffset.Y > 0.0f) ? Style.ShadowOffset.Y * AllottedGeometry.Scale : 0.0f
	);
	DrawShadowOffset = TransformPoint(InverseScale, DrawShadowOffset);
	FVector2D DrawTextOffset(
		(Style.ShadowOffset.X < 0.0f) ? -Style.ShadowOffset.X * AllottedGeometry.Scale : 0.0f,
		(Style.ShadowOffset.Y < 0.0f) ? -Style.ShadowOffset.Y * AllottedGeometry.Scale : 0.0f
	);
	DrawTextOffset = TransformPoint(InverseScale, DrawTextOffset);

	//由于逐字符绘制性能消耗大, 将这些非逐字符计算的移到遍历外, 确保每paint调用仅一次
	FLinearColor OutLineTint = InWidgetStyle.GetColorAndOpacityTint() * Style.Font.OutlineSettings.OutlineColor;
	FLinearColor SourceColor = InWidgetStyle.GetColorAndOpacityTint() * Style.ColorAndOpacity.GetColor(InWidgetStyle);
	
	//每个Glyph的渲染偏移, 遍历累计
	float LayoutX = 0.f;
	//Glyph高度, 不用逐Glyph计算, 一般等高
	float Height = ShapedText->GetMaxTextHeight();
	//Glyph计数
	int32 i = 0;
	//初始层int, 内部逐Glyph不修改层数. 阴影层低于Glyph层
	int32 ShadowLayer = ++LayerId;
	int32 GlyphLayer = ++LayerId;
	//逐Glyph渲染
	for (FShapedGlyphEntry Glyph : GlyphEntrys)
	{
		//Glyph的初始和结束位置, 不以0开始, 例如: xx<wave>xx</>, begin为2
		int32 Begin = Glyph.SourceIndex;
		int32 End = Begin + Glyph.NumCharactersInGlyph;

		//计算每个Glyph宽度, 用于下一个Glyph位置偏移
		float Width = 0.f;
		if(TOptional<int32> TWidth = ShapedText->GetMeasuredWidth(Begin, End);TWidth.IsSet())
		{
			Width = TWidth.GetValue();
		}
		
		FVector2D CharSize = FVector2D(Width, Height);
		CharSize = TransformPoint(InverseScale,CharSize);

		//构建用于用户查看和修改的结构体
		FWaveCharAttriContext Attributes = FWaveCharAttriContext();
		Attributes.Position = PaintBlockOffset + FVector2D(LayoutX, 0.f);
		Attributes.Center = FVector2D(.5f);
		Attributes.Color = SourceColor;

		//调用callback, 由蓝图修改
		if(CharDelegate.ExecuteIfBound(i,GetUpdateTime(),Attributes))
		{
			++i;
		}
		
		//将文本和阴影一致的算量提前预制
		FVector2D RotationCenter = Style.Font.Size * Attributes.Center * Attributes.Scale + FVector2D(Style.Font.OutlineSettings.OutlineSize, 0.f);
		FVector2D Transform = Attributes.Position - (Attributes.Scale - 1) * Style.Font.Size * Attributes.Center;
		//如需渲染阴影
		if (ShouldDropShadow)
		{
			//为每个Glyph创建独立序列用于渲染
			FShapedGlyphSequencePtr ShadowGlyph = BlockTextContext.ShapedTextCache->FindOrAddShapedText(
			FCachedShapedTextKey(FTextRange(Begin, End), Attributes.Scale * StartScale, BlockTextContext, ShadowFontInfo),
			**Text,
			BlockTextContext.TextDirection);

			//绘制文本阴影. 暂不提供过多参数修改接口, 例如阴影的逐Glyph颜色等, 后续根据需求开放
			FSlateDrawElement::MakeRotatedShapedText(
		   OutDrawElements,
			ShadowLayer,
			AllottedGeometry.ToPaintGeometry(CharSize,FSlateLayoutTransform(Transform + DrawShadowOffset)),
			ShadowGlyph.ToSharedRef(),
			DrawEffects,
			InWidgetStyle.GetColorAndOpacityTint() * Style.ShadowColorAndOpacity,
			OutLineTint,
			FMath::DegreesToRadians(Attributes.Angle),
			RotationCenter,
			FSlateDrawElement::RelativeToElement
			);
		}
		
		FShapedGlyphSequencePtr FixedGlyph = BlockTextContext.ShapedTextCache->FindOrAddShapedText(
		FCachedShapedTextKey(FTextRange(Begin, End), Attributes.Scale * StartScale, BlockTextContext, Style.Font),
		**Text,
		BlockTextContext.TextDirection);
		
		FSlateDrawElement::MakeRotatedShapedText(
	   OutDrawElements,
		GlyphLayer,
		AllottedGeometry.ToPaintGeometry(CharSize,FSlateLayoutTransform(Transform + DrawTextOffset)),
		FixedGlyph.ToSharedRef(),
		DrawEffects,
		Attributes.Color,
		OutLineTint,
		FMath::DegreesToRadians(Attributes.Angle),
		RotationCenter,
		FSlateDrawElement::RelativeToElement
		);
		
		LayoutX += CharSize.X;
	}

	return LayerId;
}

void FRichTextWaveRun::UpdateManualTime(float InTime, bool SwitchToManualMode)
{
	ManualTime = InTime;
	if (SwitchToManualMode && Mode != UpdateMode::Manual)
	{
		//todo: 这个版本不keep current , 下个版本开发
		SetUpdateMode(UpdateMode::Manual, false);
	}
}

void FRichTextWaveRun::SetUpdateMode(UpdateMode InMode, bool KeepCurrent)
{
	if (KeepCurrent)
	{
		GapTime = GetTimeByMode(InMode,true) - GetTimeByMode(Mode,false);
	}
	else
	{
		GapTime = 0.f;
	}
	this->Mode = InMode;
}

float FRichTextWaveRun::GetUpdateTime() const
{
	return GetTimeByMode(Mode, false);
}

float FRichTextWaveRun::GetTimeByMode(UpdateMode InMode, bool RawTime) const
{
	float Time = 0.f;
	if(InMode == UpdateMode::AutoRealGameTime)
	{
		Time = FGameTime::GetTimeSinceAppStart().GetRealTimeSeconds();
	}
	//todo: 下个版本开发
	/*else if(InMode == UpdateMode::AutoWorldTime)
	{
		Time = FGameTime::GetTimeSinceAppStart().GetWorldTimeSeconds();
	}*/
	else if(InMode == UpdateMode::Manual)
	{
		Time = ManualTime;
	}
	return RawTime ? Time : Time - GapTime;
}

FRichTextWaveDecorator::FRichTextWaveDecorator(URichTextBlock* InOwner)
: Owner(InOwner)
{
}

bool FRichTextWaveDecorator::Supports(const FTextRunParseResults& RunParseResult, const FString& Text) const
{
	//<wave amp="5" speed="3">1</>根据类似关键字包裹的应用. todo:如果返回true就是无视关键字全部应用,可以作为UObj选项开关
	return RunParseResult.Name == UWaveBlock->KeyWord;
}

TSharedRef<ISlateRun> FRichTextWaveDecorator::Create(const TSharedRef<class FTextLayout>& TextLayout,const FTextRunParseResults& RunParseResult, const FString& OriginalText, const TSharedRef<FString>& InOutModelText,const ISlateStyle* Style)
{
	FTextRange ModelRange;
	ModelRange.BeginIndex = InOutModelText->Len();

	FString Content = OriginalText.Mid(RunParseResult.ContentRange.BeginIndex,RunParseResult.ContentRange.EndIndex- RunParseResult.ContentRange.BeginIndex);

	*InOutModelText += Content;

	ModelRange.EndIndex = InOutModelText->Len();
	
	FTextRunInfo RunInfo(RunParseResult.Name, FText::FromString(Content));
	for (const TPair<FString, FTextRange>& Pair : RunParseResult.MetaData)
	{
		RunInfo.MetaData.Add(Pair.Key, OriginalText.Mid(Pair.Value.BeginIndex, Pair.Value.EndIndex - Pair.Value.BeginIndex));
	}

	const FTextBlockStyle& TextStyle = Owner->GetCurrentDefaultTextStyle();

	//绑定call及同步初始变量
	TSharedRef<FRichTextWaveRun> RichTextWaveRun = MakeShared<FRichTextWaveRun>(RunInfo,InOutModelText,TextStyle,ModelRange);
	RichTextWaveRun->CharDelegate.BindUObject(UWaveBlock,&URichTextBlockWaveDecorator::CustomPerChar);

	UWaveBlock->OnUpdateTime.BindSP(RichTextWaveRun, &FRichTextWaveRun::UpdateManualTime);
	UWaveBlock->OnSetUpdateMode.BindSP(RichTextWaveRun, &FRichTextWaveRun::SetUpdateMode);
	UWaveBlock->OnGetTime.BindSP(RichTextWaveRun, &FRichTextWaveRun::GetUpdateTime);
	
	RichTextWaveRun->SetUpdateMode(UWaveBlock->StartMode, false);
	
	return RichTextWaveRun;
}

TSharedPtr<ITextDecorator> URichTextBlockWaveDecorator::CreateDecorator(URichTextBlock* InOwner)
{
	TSharedRef RichTextWaveDecorator = MakeShared<FRichTextWaveDecorator>(InOwner);
	RichTextWaveDecorator->UWaveBlock = this;
	return RichTextWaveDecorator;
}


void URichTextBlockWaveDecorator::UpdateManualTime(float InTime, bool SwitchToManualMode)
{
	OnUpdateTime.ExecuteIfBound(InTime, SwitchToManualMode);
}
//todo: 下个版本开发
/*void URichTextBlockWaveDecorator::SetUpdateMode(UpdateMode InMode, bool KeepCurrent)
{
	OnSetUpdateMode.ExecuteIfBound(InMode, KeepCurrent);
}

float URichTextBlockWaveDecorator::GetCurrentTime()
{
	if(OnGetTime.IsBound())
	{
		return OnGetTime.Execute();
	}
	return 0.0f;
}*/

void URichTextBlockWaveDecorator::CustomPerChar_Implementation(const int32 CharIndex, const float CurrentTime, UPARAM(ref) FWaveCharAttriContext& CharAttriContext)
{
}

